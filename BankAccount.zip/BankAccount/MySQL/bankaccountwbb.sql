insert into bankaccounts (type,amount,user_id) values ("saving", 100000.00, 1);
insert into bankaccounts (type,amount,user_id) values ("checking", 500.00, 1);
insert into bankaccounts (type,amount,user_id) values ("offshore", 500000.00, 1);
select * from bankaccountschema.bankaccounts;
