insert into users (first_name, last_name, email, password) values ("YD", "carp", "dsnooze.boog@carp.com", 1234325);
select * from users