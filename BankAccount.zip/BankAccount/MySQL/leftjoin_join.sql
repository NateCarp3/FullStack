SELECT * FROM bankaccountschema.bankaccounts join users on user_id = users.id;
SELECT * FROM users left join bankaccounts on users.id = user_id;