from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import account
from flask_app.models.account import BankAccount


class User:
    def __init__(self, data):
        self.id = data['id']
        self.first_name =data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.account_list = []

    @classmethod
    def get_all_users_with_accounts(cls, data):
        query = "SELECT * FROM users left join bankaccounts on users.id = bankaccounts.user_id WHERE users.id = %(user_id)s;"
        results = connectToMySQL('bankaccountschema').query_db(query, data)
        user = cls(results[0])
        print(user)
        for row in results:
            account_info = {
                'id': row['bankaccounts.id'],
                'type': row['type'],
                'amount': row['amount'],
                'created_at': row['bankaccounts.created_at'],
                'updated_at': row['bankaccounts.updated_at'],
            }
            use = account.BankAccount(account_info)
            user.account_list.append(use)
        return user

    @classmethod
    def get_all_users(cls):
        query = "SELECT * FROM users;"
        results = connectToMySQL('bankaccountschema').query_db(query)
        users = []
        for user in results:
            users.append(cls(user))
        return users

    @classmethod
    def get_one_user(cls, data):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL("bankaccountschema").query_db(query,data)
        user = cls(results[0])
        return user

    @classmethod
    def create_user(cls, data):
        query = "INSERT INTO users (first_name, last_name, email, password) VALUES ( %(fname)s, %(lname)s, %(email)s, %(password)s);"
        results = connectToMySQL('bankaccountschema').query_db(query,data)
        return results

    @classmethod
    def update_user(cls, data):
        query = "UPDATE users SET first_name = %(fname)s, last_name = %(lname)s, email = %(email)s, password = %(password)s WHERE id = %(id)s;"
        results = connectToMySQL("bankaccountschema").query_db(query,data)
        return results

    @classmethod
    def delete_user(cls, user_id):
        query = f"DELETE FROM users Where id = {user_id}"
        results = connectToMySQL("bankaccountschema").query_db(query)
        return results