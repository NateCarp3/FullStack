from flask_app.config.mysqlconnection import connectToMySQL
import pprint



class BankAccount:
    def __init__(self, data):
        self.id = data['id']
        self.type = data['type']
        self.amount = data['amount']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def createAccount(cls, data):
        query = "INSERT INTO bankaccounts (type, amount, user_id) values (%(type)s, %(amount)s, %(id)s);"
        results = connectToMySQL('bankaccountschema').query_db(query, data)
        return results

