from flask_app import app
from flask import render_template, session, request, redirect
from flask_app.models.user import User
from flask_app.models.account import BankAccount


@app.route("/create_account/<int:id>", methods=["POST"])
def new_account(id):
    data = {
        'id':id,
        'type': request.form['type'],
        'amount': request.form['amount'],
    }
    account = BankAccount.createAccount(data)
    return redirect('/')

@app.route("/add_account/<int:id>")
def add_account(id):
    data = {
        'id': id
    }
    user = User.get_one_user(data)
    return render_template('add.html', user = user)