from flask_app import app
from flask import render_template, session, request, redirect
from flask_app.models.user import User

@app.route('/')
def index():
    user = User.get_all_users()
    return render_template('index.html', user = user)

@app.route('/showUser/<int:id>')
def showOneUser(id):
    data = {
        'id': id
    }
    user = User.get_one_user(data)
    return render_template('show.html', user = user)

@app.route('/create_user', methods=['POST'])
def create_user():
    User.create_user(request.form)
    print(f"this info is from the form int he server.py line 19{request.form}")
    return redirect("/")

@app.route('/register')
def register():
    return render_template("register.html")

@app.route('/update_user/<int:id>', methods=["POST"])
def update_user(id):
    user = User.get_one_user( id)
    return render_template("edit.html", user = user)

@app.route('/updateUser/<int:id>')
def edit_page(id):
    user = User.update_user(request.form, id)
    return redirect('/')

@app.route('/delete/<int:user_id>')
def delete_user(user_id):
    user = User.delete_user(user_id)
    return redirect('/')

@app.route('/show_accounts/<int:user_id>')
def show_account(user_id):
    data = {
        'user_id': user_id
    }
    userAccounts = User.get_all_users_with_accounts(data)
    return render_template('show_one_with_accounts.html', userAccounts = userAccounts)
