from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.show import Show
from flask_app.models.user import User

@app.route('/add_show', methods=['POST'])
def show():
    show = Show.add_show(request.form)
    return redirect('/')

@app.route('/show/<int:show_id>')
def show(show_id):
    data = {
        'show_id':show_id
    }
    show = Show



