from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Show:
    def __init__(self, data):
        self.id = data['id']
        self.title = data['title']
        self.network = data['network']
        self.release_date = data['release_date']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM tv_show;"
        results = connectToMySQL("tv_shows").query_db(query)
        print(results)
        programs = []
        for program in results:
            programs.append(cls(program))
        return programs

    @classmethod
    def add_show(cls, data):
        query = "INSERT INTO tv_show (title, network, release_date, description, user_id) VALUES (%(title)s, %(network)s, %(release_date)s, %(description)s, %(user_id)s);"
        results = connectToMySQL("tv_shows").query_db(query, data)
        return results

    @classmethod
    def get_show_info(cls,data):
        query = 'SELECT * FROM tv_show where user_id = %(user_one)s;'
        results = connectToMySQL('tv_shows').query_db(query, data)
        user_in_db = cls(results[0])
        return user_in_db