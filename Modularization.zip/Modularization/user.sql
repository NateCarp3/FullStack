SELECT * FROM userschema.user;
INSERT INTO userschema.user (first_name, last_name, email)
VALUES ("Adrien", "Dion", "ad@dojo.com"), ("Nate", "Carpenter", "thegreattt@gmail.com")