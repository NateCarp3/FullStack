from flask_app import app
from flask import render_template, redirect, request
from flask_app.models.nate import Nate

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/info")
def inf():
    user = Nate.get_all()
    return render_template("info.html", user = user)

@app.route("/new/<int:user_id>", methods=["POST"])
def addInfo(user_id):
    data = {
        'user_id': user_id
    }
    Nate.save(request.form)
    user = Nate.get_one(data)
    return redirect("/one", user = user)

@app.route("/one/<int:user_id>", methods=["POST"])
def addOne(user_id):
    data = {
        'user_id': user_id
    }
    user = Nate.get_one(data)
    return render_template("formData.html", user = user)