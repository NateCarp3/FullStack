from flask_app import app
from flask_app.controllers import nates
from flask_app.models import nate

if __name__=="__main__":
    app.run(debug=True)