from mySQLconnection import connectToMySQL

class User:
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
#'''All inputs from the database are converted into class elements'''

    @classmethod
    def get_all_users(cls): #cls is the class name
        query = "SELECT * FROM users"
        results = connectToMySQL("planets").query_db(query) # Creates a list of dictionaries from all of the users
        users = []
        for user in results:
            users.append(cls(user))
        return users

    @classmethod
    def create(cls,data):
        query = "INSERT INTO users (first_name, last_name, email) VALUES (%(first_name)s, %(last_name)s, %(email)s);" # the key for the value has that notation
        results = connectToMySQL("planets").query_db(query,data) # Creates a list of dictionaries from all of the users
        return results
