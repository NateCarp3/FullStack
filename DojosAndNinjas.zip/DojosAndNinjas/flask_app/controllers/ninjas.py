from flask_app import app
from flask import render_template, redirect, request
from flask_app.models.ninja import Ninja

@app.route('/')
def index_two():
    render_template

@app.route('/add_ninja', methods=['POST'])
def ninj():
    dojo = Ninja.add_ninja(request.form)
    return redirect('/')