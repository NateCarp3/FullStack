from flask_app import app
from flask import render_template, redirect, request
from flask_app.models.dojo import Dojo

@app.route('/')
def index():
    dojo = Dojo.get_all()
    return render_template('index.html', dojo = dojo)

@app.route('/new', methods=["POST"])
def addUser():
    Dojo.save(request.form)
    return redirect('/')

@app.route('/ninja')
def ninja():
    return render_template('ninja.html')