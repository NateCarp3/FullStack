from flask_app import app
from flask import render_template, redirect, request
from flask_app.models.dojo import Dojo

@app.route('/')
def index():
    dojo = Dojo.get_all()
    return render_template('index.html', dojo = dojo)

@app.route('/new', methods=["POST"])
def addUser():
    Dojo.save(request.form)
    return redirect('/')

@app.route('/ninja')
def ninja():
    dojos = Dojo.get_all()
    print(dojos)
    return render_template('ninja.html', dojos = dojos)

@app.route('/show/<int:dojo_id>')
def show(dojo_id):
    data = {
        'dojo_id': dojo_id
    }
    dojos = Dojo.get_one_with_ninjas(data)
    print(dojos)
    return render_template('show.html', dojos = dojos)