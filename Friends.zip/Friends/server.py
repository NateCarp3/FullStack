from flask import Flask, render_template, request, redirect
# import the class from friend.py
from friends import Friend
app = Flask(__name__)
@app.route("/")
def index():
    # call the get all classmethod to get all friends
    all_friends = Friend.get_all()
    print(all_friends)
    return render_template("index.html", friends = all_friends)

@app.route('/create_friend', methods=["POST"])
def create_friend():
    data = {
        "fname": request.form["fname"],
        "lname": request.form["lname"],
        "occ": request.form["occ"]
    #We then pass the data dictionary into the save method from the Friend class
    }
    Friend.save(data)
    return redirect('/')

@app.route('/friend/show/<int:id>')
def show(id):
    # calling the get_one method and supplying it with the id of the friend we want to get
    friend=Friend.get_one(id)
    return render_template("show_friend.html",friend=friend)

@app.route('/friend/create', methods=['POST'])
def create():
    Friend.save(request.form)
    return redirect('/')

@app.route('/friend/update/<int:id>',methods=['POST'])
def update(id):
    Friend.update(request.form, id)
    return redirect('/users')

@app.route('/friend/delete/<int:id>')
def delete(id):
    Friend.delete(id)
    return redirect('/')

            
if __name__ == "__main__":
    app.run(debug=True)
