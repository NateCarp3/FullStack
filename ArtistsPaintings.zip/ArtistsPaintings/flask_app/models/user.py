from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import painting
from flask_app.models.painting import Painting
from flask import flash
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 

class User:
    def __init__(self, data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.paintings = []

    @classmethod
    def create_user(cls, data):
        query = "INSERT INTO user (first_name, last_name, email, password) VALUES (%(first_name)s, %(last_name)s, %(email)s, %(password)s);"
        results = connectToMySQL("artists_paintings").query_db(query, data)
        return results

    @classmethod
    def get_user_info(cls, data):
        query = 'SELECT * FROM user WHERE id = %(id)s;'
        results = connectToMySQL("artists_paintings").query_db(query, data)
        user = cls(results[0])
        return user

    @classmethod
    def get_user_info_login(cls, data):
        query = 'SELECT * FROM user WHERE email = %(email)s;'
        results = connectToMySQL("artists_paintings").query_db(query, data)
        return cls(results[0])

    @classmethod
    def get_user_with_paintings(cls, data):
        query = "SELECT * FROM user left join painting on user.id = paintings.user_id where user.id = %(user_id)s;"
        results = connectToMySQL("artists_paintings").query_db(query, data)
        user = cls(results[0])
        print(user)
        for row in results:
            painting_data = {
                'id': row['ninjas.id'],
                'title': row['title'],
                'description': row['description'],
                'price': row['price'],
                'created_at': row['ninjas.created_at'],
                'updated_at': row['ninjas.updated_at']
            }
            paint = painting.Painting(painting_data)
            user.paintings.append(paint)
        return user

    @staticmethod
    def validate_user(user):
        is_valid =True
        if not EMAIL_REGEX.match(user['email']):
            flash("Invalid email address!")
            is_valid = False
        if len(user['first_name']) < 2:
            flash('First Name must be greater than 2 characters.')
            is_valid = False
        if len(user['last_name']) < 2:
            flash('Last Name must be greater than 2 characters.')
            is_valid = False
        if len(user['password']) < 8:
            flash('Last Name must at least 8 characters.')
            is_valid = False
        if user['confirm_password'] != user['password']:
            flash('Your passwords do not match.')
            is_valid = False
        print(is_valid)
        return is_valid
