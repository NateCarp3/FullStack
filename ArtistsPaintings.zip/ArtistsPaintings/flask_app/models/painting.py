from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash


class Painting:
    def __init__(self, data):
        self.id = data['id']
        self.title = data['title']
        self.description = data['description']
        self.price = data['price']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.painted_by = ''

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM painting;"
        results = connectToMySQL("artists_paintings").query_db(query)
        print(results)
        paintings = []
        for painting in results:
            paintings.append(cls(painting))
        return paintings

    @classmethod
    def add_painting(cls, data):
        query = "INSERT INTO painting (title, description, price, user_id) VALUES (%(title)s, %(description)s, %(price)s, %(user_id)s);"
        results = connectToMySQL("artists_paintings").query_db(query, data)
        return results

    @classmethod
    def get_one(cls,data):
        query = 'SELECT * FROM painting join user on user_id = user.id painting.id = %(painting_id)s;'
        results = connectToMySQL('artists_paintings').query_db(query, data)
        paintings = []
        for painting in results:
            x = cls(painting)
            x.painted_by = painting['first_name']
            paintings.append(x)
        return paintings

    @classmethod
    def delete_painting(cls):
        query = "DELETE FROM painting WHERE id = %(painting_id)s;"
        results = connectToMySQL('artists_paintings').query_db(query)
        return results