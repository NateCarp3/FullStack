from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.painting import Painting
from flask_app.models.user import User

@app.route('/add_painting', methods=['POST'])
def show():
    data = {
        'painting_id':request.form['id'],
        'title':request.form['title'],
        'description':request.form['description'],
        'price':request.form['price']
    }

    session['painting_id']=request.form['id']
    session['title']=request.form['title']
    session['description']=request.form['description']
    session['price']=request.form['price']

    painting = Painting.add_painting(request.form)
    return redirect('/paintings')

@app.route('/painting/<int:painting_id>')
def show_display(painting_id):
    data = {
        'painting_id':painting_id
    }
    painting = Painting.get_one(data)
    print(painting)
    return render_template('show.html', painting = painting)

@app.route('/edit_show/<int:painting_id>')
def edit_page(painting_id):
    data = {
        'id':painting_id
    }
    show = Painting.get_one(data)
    return render_template('edit_show.html', show = show) 

@app.route('/delete/<int:painting_id>')
def delete_page(painting_id):
    data = {
        'id':painting_id
    }
    painting = Painting.delete_painting(data)
    return redirect('/paintings') 






