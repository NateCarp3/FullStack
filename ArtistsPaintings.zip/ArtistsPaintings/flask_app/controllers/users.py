from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.user import User
from flask_app.models.painting import Painting 
from flask_bcrypt import Bcrypt

from flask import flash
bcrypt = Bcrypt(app)
@app.route('/')
def user_index():
    return render_template('index.html')

@app.route('/create_user', methods = ["POST"])
def create_use():
    if not User.validate_user(request.form):
        return redirect('/')
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    data = {
            'first_name': request.form['first_name'],
            'last_name': request.form['last_name'],
            'email': request.form['email'],
            'password': pw_hash
    }
    session['first_name']= request.form['first_name']
    session['last_name'] = request.form['last_name']
    session['user_id'] = request.form['id']
    user_info = User.create_user(data)
    return redirect('/paintings')

@app.route('/login_user', methods=["POST"])
def login():
    user_in_db = User.get_user_info_login(request.form)
    if not user_in_db:
        return redirect('/')
    if not bcrypt.check_password_hash(user_in_db.password, request.form['password']):
        # if we get False after checking the password
        flash("Invalid Email/Password")
        return redirect('/')
    session['user_id'] = user_in_db.id
    return redirect('/paintings')

@app.route('/paintings')
def dashb():
    if "user_id" not in session:
        redirect('/')
    data = {
        'id': session['user_id']
    }
    user_one = User.get_user_info(data)
    paintings = Painting.get_all()
    return render_template('dashboard.html', paintings = paintings, user_one = user_one)

@app.route('/new')
def new_show():
    data = {
        'id':session['user_id']
    }
    user_one = User.get_user_info(data)
    return render_template('new_painting.html', user_one = user_one)