from flask_app import app
from flask_app.controllers import users
from flask_app.models import user
from flask_app.controllers import paintings
from flask_app.models import painting

if __name__=="__main__":
    app.run(debug=True)