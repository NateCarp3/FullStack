from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Car:
    def __init__(self, data):
        self.id = data['id']
        self.price = data['price']
        self.model = data['model']
        self.make = data['make']
        self.year = data['year']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.posted_by = ''

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM car;"
        results = connectToMySQL("cars_schema").query_db(query)
        print(results)
        cars = []
        for car in results:
            cars.append(cls(car))
        return cars

    @classmethod
    def add_car(cls, data):
        query = "INSERT INTO car (price, model, make, year, description, user_id) VALUES (%(price)s, %(model)s, %(make)s, %(year)s, %(description)s, %(user_id)s);"
        results = connectToMySQL("cars_schema").query_db(query, data)
        return results

    @classmethod
    def get_car_info(cls, data):
        query = 'SELECT * FROM car join user on user_id = user.id where car.id = %(car_id)s;'
        results = connectToMySQL('cars_schema').query_db(query, data)
        car_in_db = cls(results[0])
        car_in_db.posted_by = results[0]['first_name']
        return car_in_db

    @classmethod
    def delete(cls, car_id):
        query = f'DELETE FROM car WHERE car.id = {car_id};'
        results = connectToMySQL('cars_schema').query_db(query)
        return results

    @staticmethod
    def validate_user(car):
        is_valid =True
        if len(car['year']) < 0:
            flash('Year must be greater than 0.')
            is_valid = False
        if len(car['price']) < 0:
            flash('Price must at greater than 0.')
            is_valid = False
        print(is_valid)
        return is_valid
