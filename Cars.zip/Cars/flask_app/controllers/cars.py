from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.car import Car
from flask_app.models.user import User

@app.route('/add_car', methods=['POST'])
def show_car():
    car = Car.add_car(request.form)
    return redirect('/dashboard')

@app.route('/show/<int:car_id>')
def show_display(car_id):
    data = {
        'car_id':car_id
    }
    car = Car.get_car_info(data)
    return render_template('show.html', car = car)

@app.route('/edit/<int:car_id>')
def edit_page(car_id):
    data = {
        'car_id':car_id
    }
    car = Car.get_car_info(data)
    return render_template('edit_show.html', car = car)

@app.route('/delete/<int:car_id>')
def delete(car_id):
    car = Car.delete(car_id)
    return redirect('/dashboard')