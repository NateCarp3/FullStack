from flask import Flask, render_template, redirect, request
from crud import Crud
app = Flask(__name__)



@app.route('/users')
def index():
    all_users = Crud.get_all()
    print(all_users)
    return render_template('index.html', all_users = all_users)

@app.route('/add')
def add():
    return render_template('add_user.html')

@app.route('/new', methods=["POST"])
def addUser():
    Crud.save(request.form)
    return redirect('/users')

if __name__=="__main__":
    app.run(debug=True)