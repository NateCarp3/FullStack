from flask import Flask, render_template, redirect, request
from crud import Crud
app = Flask(__name__)

@app.route('/')
def index():
    user = Crud.get_all()
    print(user)
    return render_template('index.html', user = user)

@app.route('/add')
def add():
    return render_template('add_user.html')

@app.route('/new', methods=["POST"])
def addUser():
    Crud.save(request.form)
    return redirect('/')

@app.route('/edit_user/<int:user_id>')
def edit(user_id):
    print(user_id)
    data = {
        'user_id': user_id
    }
    user = Crud.get_one(data)
    return render_template('edit.html', user = user)

@app.route('/update_user', methods=["POST"])
def update():
    user = Crud.update_user(request.form)
    return redirect('/')

@app.route('/delete/<int:user_id>')
def delete_user(user_id):
    user = Crud.delete(user_id)
    return redirect('/')

@app.route('/show/<int:user_id>')
def show(user_id):
    data = {
        'user_id': user_id
    }
    user = Crud.get_one(data)
    return render_template('show.html', user = user)







if __name__=="__main__":
    app.run(debug=True)