from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.log import User
from flask_bcrypt import Bcrypt
from flask import flash
bcrypt = Bcrypt(app)

@app.route('/')
def index():
        return render_template('index.html')

@app.route('/create_user', methods=['POST'])
def create_user():
        if not User.validate_user(request.form):
            return redirect('/')
        pw_hash = bcrypt.generate_password_hash(request.form['password'])
        data = {
            'first_name': request.form['first_name'],
            'last_name': request.form['last_name'],
            'email': request.form['email'],
            'password': pw_hash
        }
        session['user_id'] = User.save(data)
        return redirect('/home')

@app.route('/login_user', methods=["POST"])
def login():
    user_in_db = User.get_user_info(request.form)
    if not user_in_db:
        return redirect('/')
    if not bcrypt.check_password_hash(user_in_db.password, request.form['password']):
        # if we get False after checking the password
        flash("Invalid Email/Password")
        return redirect('/')
    session['user_id'] = user_in_db.id
    return redirect('/home')


@app.route('/home')
def home():
    if "user_id" not in session:
        redirect('/')
    return render_template('home.html')
