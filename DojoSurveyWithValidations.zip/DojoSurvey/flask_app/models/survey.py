from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Survey:
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.location = data['location']
        self.language = data['language']
        self.comments = data['comments']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls, data):
        query = "INSERT INTO survey (name, location, language, comments) VALUES (%(name)s, %(location)s, %(language)s, %(comments)s);"
        results = connectToMySQL('surveyschema').query_db(query, data)
        return results

    @classmethod
    def get_survey_info(cls, data):
        query = "SELECT * FROM survey WHERE id = %(user_id)s;"
        results = connectToMySQL("surveyschema").query_db(query, data)
        user = cls(results[0])

    @staticmethod
    def validate_survey(survey):
        is_valid = True
        if len(survey['name']) < 2:
            flash("Name must be at least two characters")
            is_valid = False
        if len(survey['location']) < 2:
            flash("Location must be at least two characters")
            is_valid = False
        if len(survey['language']) < 2:
            flash("Language must be at least two characters")
            is_valid = False
        if len(survey['comments']) < 2:
            flash("Comment must be at least two characters")
            is_valid = False
        return is_valid
