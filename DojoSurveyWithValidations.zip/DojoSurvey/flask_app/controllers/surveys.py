from flask_app import app
from flask import render_template, redirect, request, session
from flask_app.models.survey import Survey

@app.route('/')
def surveyDojo():
    return render_template('index.html')

@app.route('/survey', methods=["POST"])
def result():
    if not Survey.validate_survey(request.form):
        return redirect('/')
    data = {
        "name":request.form["name"],
        "location":request.form["location"],
        "language":request.form["language"],
        "comments":request.form["comments"]

    }
    print(request.form)
    survey = Survey.save(data)
    return redirect(f'/display/{survey}')

@app.route('/display/<int:user_id>')
def display(user_id):
    data = {
        'user_id': user_id
    }
    survey_info = Survey.get_survey_info(data)
    print(request.form)
    return render_template('display.html', survey_info = survey_info)